var DEF_PREF={
  updateInterval:10,
  alertSound:true,
  customSound:false,
  soundUrl:"",
  soundData:"",
  showNotification:true,
  autoHideNotification:true,
  resetCounter:false
}
